java -Xmx1024m -Dphenex.version="1.0-beta23-nexml" -Dphenex.build="2009-07-14_14:34:05" -jar lib/phenex.jar
