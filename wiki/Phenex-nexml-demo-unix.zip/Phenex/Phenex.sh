java -Xmx1024m -Dphenex.version="1.0-beta21-NeXML-demo" -Dphenex.build="2009-06-24_11:29:18" -jar lib/phenex.jar
